`1.2.0`
-------

- Logging

`1.1.0`
-------

- Parse Request Body

`1.0.0`
-------

- Init version
