
function Loader(){
 var loaderContainer = document.querySelector(".loader_container");
    loaderContainer.style.display = "none";

}

setTimeout(()=>{
Loader()
},2000)
