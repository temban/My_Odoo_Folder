
// Import the function from file1.js
import { sayHello } from './fille1.js';

// Call the imported function
sayHello('Johnny');
