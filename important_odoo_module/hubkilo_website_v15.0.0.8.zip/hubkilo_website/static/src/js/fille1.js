
// Export a function
export function sayHello(name) {
    console.log(`Hello, ${name}!`);
}
